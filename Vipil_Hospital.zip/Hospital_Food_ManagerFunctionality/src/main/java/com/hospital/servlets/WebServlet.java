package com.hospital.servlets;

public @interface WebServlet {

}
