import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PatientServlet") // Ensure Servlet 3.0+ is configured
public class PatientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	  String name = request.getParameter("patientName");
          String age = request.getParameter("patientAge");
          String gender = request.getParameter("patientGender");
          String diseases = request.getParameter("diseases");
          String allergies = request.getParameter("allergies");
          String doctor = request.getParameter("attendingDoctor");
          String bedNumber = request.getParameter("bedNumber");
          String roomNumber = request.getParameter("roomNumber");
          String floorNumber = request.getParameter("floorNumber");
          String contact = request.getParameter("contact");
          String emergencyContact = request.getParameter("emergencyContact");

          try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "your_username", "your_password");
               PreparedStatement stmt = conn.prepareStatement(
                       "INSERT INTO PatientDetails (PatientName, Age, Gender, Diseases, Allergies, AttendingDoctor, BedNumber, RoomNumber, FloorNumber, ContactInfo, EmergencyContact) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
              stmt.setString(1, name);
              stmt.setInt(2, Integer.parseInt(age));
              stmt.setString(3, gender);
              stmt.setString(4, diseases);
              stmt.setString(5, allergies);
              stmt.setString(6, doctor);
              stmt.setInt(7, Integer.parseInt(bedNumber));
              stmt.setInt(8, Integer.parseInt(roomNumber));
              stmt.setInt(9, Integer.parseInt(floorNumber));
              stmt.setString(10, contact);
              stmt.setString(11, emergencyContact);

              stmt.executeUpdate();
              response.sendRedirect("success.jsp");
          } catch (Exception e) {
              e.printStackTrace();
              response.sendRedirect("error.jsp");
          }
    }
}
